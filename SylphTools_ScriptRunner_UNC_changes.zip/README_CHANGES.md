# SylphTools — Script Runner + UNC Checker changes

Giải nén và ghi đè các file này vào đúng đường dẫn tương ứng trong repo
(cấu trúc thư mục trong zip khớp với repo gốc).

## Native (C++/CMake)
- `native/luau_wrapper/CMakeLists.txt` — thêm `LUAU_EXTERN_C ON` (fix lỗi
  linker "undefined symbol: lua_pushstring/lua_error/..."), thêm bước
  generate `sylph_gui_bootstrap_embedded.h` từ file `.lua` lúc build.
- `native/luau_wrapper/luau_bridge.cpp` — viết lại theo mô hình
  handle-based (session sống qua nhiều lần gọi, cần cho GUI preview
  tương tác), sửa bug "attempt to call a thread value"
  (lua_newthread/lua_xmove sai thứ tự stack).
- `native/luau_wrapper/sylph_gui_bootstrap.lua` — mock Roblox GUI API
  (Instance.new, UDim2, Color3, game/workspace/Players, :Connect).
  Đây là NGUỒN SỰ THẬT duy nhất — sửa file này, không sửa file
  `.h.in` hay bất kỳ bản copy nào.
- `native/luau_wrapper/sylph_gui_bootstrap_embedded.h.in` — template
  CMake dùng để tự sinh header C++ từ file `.lua` ở trên lúc build.

## Dart/Flutter
- `lib/services/luau_runner_service.dart` — FFI bindings mới:
  `runOnce()` (dùng cho UNC Checker), và
  `createSession/runInSession/snapshot/fireEvent/disposeSession`
  (dùng cho Script Runner có preview tương tác).
- `lib/models/sylph_instance_node.dart` — model parse JSON cây GUI.
- `lib/widgets/sylph_gui_preview.dart` — widget vẽ cây đó thành
  Flutter thật (Frame/TextLabel/TextButton...), bấm nút gọi ngược
  vào VM qua fireEvent.
- `lib/screens/script_runner_screen.dart` — viết lại, KHÔNG còn tab
  UNC Checker, thêm tab Output/Preview.
- `lib/screens/unc_checker_screen.dart` — MỚI, tách UNC Checker ra
  màn hình riêng.
- `lib/screens/tools_hub_screen.dart` — tách card "Script Runner" và
  "UNC Checker" thành 2 card riêng.
- `lib/routes/app_routes.dart` — thêm route `/unc-checker`.

## Sau khi copy đè
1. Commit các file trên vào repo.
2. Chạy lại CI build như cũ — không cần thêm bước gì khác, CMake tự
   sinh header lúc configure.
